# Rhetorical Geometry Analysis — Pipeline Manifest
# PROPRIETARY. This file is gitignored and does not appear in the public repository.
# Researchers and institutions seeking access to the pipeline implementation
# should contact the analyst directly.
#
# This document records which VM components were selected for the pipeline,
# which were benched, and the rationale for each decision.
# Decisions were made before document analysis began and are part of the
# locked methodology record.

---

## Pipeline Status: Locked
## Locked date: 2026-04-25
## Corresponds to: schema v0.4, methodology v0.4, rules v1.0

---

## Core Infrastructure (already assumed throughout methodology)

### HSH Geometry (Poincaré Disk Embedding)
Foundational. Governance nodes at center (r=0), peripheral nodes curving outward
by zone inertia. Not an addition — this is the manifold the entire framework assumes.
All geodesic distance computations, zone assignments, and bridge narrative detection
operate on this structure.

### Field Theory Engine
Foundational. Computes the stress-energy tensor T_μν and the healing scalar field
on hyperbolic space. Provides the repulsive forces that restore nodes toward the
governance anchor. Core infrastructure for all stress energy computation in RULE-009.

---

## Included: Core Detection Layer

### Epistatic Gate
Status: INCLUDED
Role: Second independent detection mechanism for bridge_narrative classification.

A bridge narrative suppresses the visible contradiction between an anchored_true
proposition and an anchored_false attractor without deleting either. The Hill
equation models that suppression formally:
  - P1 = anchored_true proposition (structural node)
  - P2 = bridge_narrative (regulatory node)
  - P3 = anchored_false attractor (structural node)

P2 suppresses the direct P1 → contradiction → P3 connection. Remove P2 and the
contradiction becomes directly visible in the graph.

Primary bridge detection uses bidirectional T_μν (geometric). The epistatic gate
provides a second independent signal via suppression kinetics. Two independent
signals for the same phenomenon is a substantially stronger finding than one.

### Structural Tension Auditor
Status: INCLUDED
Role: Computational basis for contextually_misleading classification.

Currently contextually_misleading is a secondary tag applied by analyst judgment.
The tidal tension calculation makes this computational rather than judgmental.

A proposition sitting geometrically close to a governance anchor in the Poincaré
disk with no formal signed edge to that anchor is under measurable tidal influence
it has not declared. That is the geometric signature of contextually misleading:
proximity to truth without explicit connection.

This replaces an analyst call with a number that goes in the output where anyone
can verify it. This is the component most likely to make the difference between
a finding that is defensible and one that is auditable.

### Veritas Geometria (Ollivier-Ricci Curvature)
Status: INCLUDED
Role: Second independent measure of edge stress.

Negative curvature on an edge indicates semantic tension. Positive curvature
indicates semantic coherence. Provides a curvature profile of the proposition
graph that is independent of T_μν.

If Veritas Geometria and T_μν agree on edge stress: the finding is robust.
If they diverge: the divergence is itself analytically interesting and belongs
in confidence_flags.

---

## Included: Infrastructure Layer

### Kalman Belief Tracker
Status: INCLUDED (infrastructure, not optional)
Role: Stabilizes the Fiedler value signal for reliable stopping criteria.

Raw lambda2 from the eigensolver is numerically noisy. Without the Kalman filter
the Fiedler value is unreliable as a stopping criterion and the SAL coherence
signal becomes hair-trigger. Required for any reliable use of spectral analysis.

### SAL Coherence
Status: INCLUDED
Role: Principled threshold for when the proposition graph is geometrically complete.

In VM: answers "has it reasoned enough to commit."
In this context: answers "is the proposition graph dense enough to produce
reliable geodesic distances."

A sparse graph early in extraction should not be committed as geometrically
complete. SAL gives the threshold for when the graph structure is real rather
than an artifact of incomplete extraction.

### Zipfian Auditor
Status: INCLUDED
Role: Complementary signal to Sheaf Holonomy for selective_omission detection.

Sheaf Holonomy's max_drift_index identifies which section contains the largest
semantic jump. The Zipfian Auditor identifies whether that section also contains
anomalous vocabulary — a term rare in the document's baseline distribution
suddenly entering the top-k.

Two independent signals pointing to the same section constitutes a locatable
finding rather than a measurement artifact. Required by RULE-015.

The Zipfian Auditor must be calibrated to content vocabulary rather than full
Zipfian distribution for 19th-century documents. See methodology v0.4 Section 4.5.

---

## Included: Conditional

### Hyphal Optimizer (Slime Mold Dynamics)
Status: INCLUDED CONDITIONALLY
Condition: Run during adversarial annealer random walks only.

In the annealer's random walks, edges that are repeatedly traversed are
load-bearing. The slime mold dynamics identify which inferential connections
are doing the most structural work.

For bridge narrative detection: the highest-traffic edges in a false attractor
cluster are the ones keeping the lie stable. Knowing which edges those are
identifies exactly where the structure would collapse if one connection
were removed. Operationally useful for confirming Signal 3 (epistatic
suppression) in RULE-011.

Not run on the full graph unconditionally — triggered by the adversarial
annealer when a bridge narrative candidate is identified.

---

## Already in Pipeline (from VM base)

### Adversarial Annealer
Already in pipeline from VM. Uses simulated annealing with Metropolis-Hastings
to search for the "most stable lie" — a belief graph configuration where spectral
coherence looks healthy but is built on circular reasoning rather than independent
evidence. Operates on a copy of the graph and never writes back. Pure diagnostic
probe for deceptive coherence.

### Diagnostic Annealer
Already in pipeline from VM. Inverse of adversarial annealer. Runs low-heat probes
to classify why specific nodes are fragile: under-evidenced, genuinely contested,
or epistasis candidates. Each diagnosis has a different prescription.

### Persistent Homology
Already in pipeline from VM. Runs topological data analysis across all edge weight
thresholds simultaneously. Detects beliefs that only barely cohere (low persistence)
and topological holes (circular reasoning loops with no independent resolution path).
Catches things lambda2 spectral analysis cannot because lambda2 measures global
connectivity at one threshold at a time.

### Kolmogorov Complexity Tax (AIC Delta)
Already in pipeline from VM (experimental module). Used by RULE-016 (false_precision)
as the primary detection tool for quantitative claims stated with more precision
than the evidence supports.

### Manifold Stress (Fisher Information Proxy)
Already in pipeline from VM (experimental module). Measures geodesic tension
between a document's stated purpose (preamble) and its operational content.

### Sheaf Holonomy (Semantic Path Obstruction)
Already in pipeline from VM (experimental module). Tests whether global consistent
meaning is preserved end-to-end across the document. High holonomy score indicates
meaning has rotated away from the document's opening. Provides max_drift_index
used by RULE-015 (selective_omission).

### Adapted NarrativeWavelet
Already in pipeline from Lore. Adapted from fiction domain (three bands: LOW/MID/HIGH)
to rhetorical document domain (four bands: normative_stable, historical_state,
empirical_event, legal_statutory). AMBIGUITY_MARGIN widened from 0.15 to 0.20.
Routes dual-band sentences to RULE-004 Pathway 2 compound detector rather than
to SRL. See methodology v0.4 Section 4 for full specification.

---

## Benched

### Constraint Policy Engine
Benched. Designed for decision-making analysis involving legitimately conflicting
obligations. Does not transfer to one-shot rhetorical document analysis where
the task is classification, not decision-making.

### Clonal Selection
Benched. Evolutionary memory consolidation tool designed for a graph that changes
over time. Rhetorical analysis is a one-shot static analysis of a fixed document.
Nothing to consolidate across sessions.

### Shadow Graph
Benched. The audit_trail field in the schema honors this concept in flattened form —
append-only log with prior and new values preserved. Full shadow graph infrastructure
is overkill for one-shot analysis.

### Stratigraphic Provenance
Benched. Same rationale as Shadow Graph. The audit_trail already captures the
essential function. Full stratigraphic model is designed for iterative analysis
across sessions, not for a single document extraction pass.

---

## Component Interaction Map

Extraction pass:
  NarrativeWavelet → RULE-004 Pathway 2 compound detector

Graph construction:
  HSH Geometry (manifold)
  Field Theory Engine (T_μν, stress tensor)
  Kalman Belief Tracker (stabilizes Fiedler value)
  SAL Coherence (graph completeness threshold)

Classification:
  Veritas Geometria (Ollivier-Ricci curvature, independent stress measure)
  Epistatic Gate (bridge narrative suppression kinetics)
  Structural Tension Auditor (tidal tension → contextually_misleading)
  Persistent Homology (topological holes, low-persistence beliefs)

Diagnostic probes (run on copies, never write back):
  Adversarial Annealer → Hyphal Optimizer (conditionally, on bridge candidates)
  Diagnostic Annealer

Selective omission detection (RULE-015):
  Sheaf Holonomy (max_drift_index)
  Zipfian Auditor (content vocabulary anomaly)
  Both signals required + documentable omission

False precision detection (RULE-016):
  Kolmogorov Complexity Tax
  Manifold Stress (supporting signal)
