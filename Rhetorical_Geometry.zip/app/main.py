"""
Rhetorical Geometry Analysis — FastAPI Backend
Accepts a pre-classified schema v0.4 partial record and runs the geometric
computation pipeline. Returns a completed schema v0.4 record.

Workflow
--------
1. Analyst and Claude collaboratively extract propositions from a document,
   applying rules_v1.md. Output is a pre-classified JSON record with
   document_metadata, anchor_registry, and proposition_table populated.
2. That JSON is submitted to POST /analyze.
3. The pipeline runs geometric computation modules (HSH geometry, field theory,
   epistatic gate, structural tension auditor, SAL coherence).
4. The completed record is saved to outputs/ and returned.

Run with:
    uvicorn main:app --reload --port 7337
"""

import sys
import os
import json
import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_PIPELINE_DIR = _PROJECT_ROOT / "Pipeline"

for p in [str(_PROJECT_ROOT), str(_PIPELINE_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

from Pipeline.rga_pipeline import run_pipeline 

# ── App setup ─────────────────────────────────────────────────────────────────
app = FastAPI(title="Rhetorical Geometry Analysis")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")

OUTPUTS_DIR = Path("outputs")
OUTPUTS_DIR.mkdir(exist_ok=True)


@app.get("/")
def root():
    return FileResponse("C:/Users/jessi/Projects/rhetorical_geometry/app/static/index.html")


@app.post("/analyze")
async def analyze(request: Request):
    """
    Accept a pre-classified schema v0.4 partial record as JSON and run
    the geometric pipeline.

    Required fields in the JSON body:
      - document_metadata  (dict)
      - anchor_registry    (list)
      - proposition_table  (list)

    Optional pass-through fields:
      - confidence_flags     (list, default [])
      - falsifiability_record (list, default [])

    Returns the completed schema v0.4 record with graph_structure,
    geometric_summary, confidence_flags, falsifiability_record,
    and audit_trail populated.
    """
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Request body must be valid JSON.")

    # Validate required fields
    for required in ("document_metadata", "anchor_registry", "proposition_table"):
        if required not in body:
            raise HTTPException(
                status_code=422,
                detail=f"Missing required field: {required}"
            )

    if not isinstance(body["anchor_registry"], list) or len(body["anchor_registry"]) == 0:
        raise HTTPException(
            status_code=422,
            detail="anchor_registry must be a non-empty list. At least one anchor is required."
        )

    if not isinstance(body["proposition_table"], list) or len(body["proposition_table"]) == 0:
        raise HTTPException(
            status_code=422,
            detail="proposition_table must be a non-empty list."
        )

    # Stamp analysis timestamp if not present
    meta = body["document_metadata"]
    if "date_of_analysis" not in meta or not meta["date_of_analysis"]:
        meta["date_of_analysis"] = datetime.datetime.utcnow().isoformat()

    # Run pipeline
    try:
        result = run_pipeline(body)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Pipeline error: {str(e)}"
        )

    # Save output
    doc_id = meta.get("document_id", "UNKNOWN")
    out_path = OUTPUTS_DIR / f"{doc_id}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    return JSONResponse(content=result)


@app.get("/outputs/{doc_id}")
def get_output(doc_id: str):
    path = OUTPUTS_DIR / f"{doc_id}.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    return FileResponse(path, media_type="application/json")


@app.get("/outputs")
def list_outputs():
    files = [f.stem for f in OUTPUTS_DIR.glob("*.json")]
    return {"analyses": sorted(files)}


@app.get("/health")
def health():
    return {
        "status": "ok",
        "pipeline": "rga_pipeline v1.0",
        "schema": "0.4",
        "stub_active": False,
    }
